import random  # Importa a biblioteca random

# Subprogramas


def constroiMatriz(l, c, min, max):  # Função que constrói as matrizes iniciais. Recebe como
    # parâmetros a quantidade de linha, coluna e os valores
    # máximos e mínimos
    m = []  # Variável m recebe uma lista vazia
    for linha in range(l):  # Laço que vai controlar a quantidade de linhas da matriz
        m.append([])  # É adicionado uma linha vazia dentro da lista
        for coluna in range(c):  # laço que vai controlar a quantidade de colunas da matriz
            m[linha].append(random.randint(min, max))  # É adicionado uma coluna com um valor inteiro aleatório em
            # determinada linha
    return m   # A nova matriz é retornada


def larguraColuna(matriz):  # Função que vai estabelecer a largura da matriz. Recebe como parametro a matriz.
    n = len(matriz)  # n recebe a quantiddade de linhas
    m = len(matriz[0])  # m recebe a quantidade de colunas
    menor = 0  # menor recebe 0
    for l in range(n):  # Laço que controla as linhas da matriz
        for c in range(m):  # Laço que controla as colunas da matriz
            if menor > matriz[l][c]:  # Se menor for maior que o elemento da matriz verificado
                menor = matriz[l][c]  # menor recebe o elemento verificado
    maior = 0  # maior recebe 0
    for l in range(len(matriz)):  # Laço que controla as linhas da matriz
        for c in range(len(matriz[l])):  # Laço que controla as colunas da matriz
            if matriz[l][c] > maior:  # Se o elemento verificado for maior que a variável maior
                maior = matriz[l][c]  # maior recebe o elemento verificado
    menor = quantosAlgarismos(menor)  # menor é modificado para a largura em caracteres do número antes armazenado
    maior = quantosAlgarismos(maior)  # maior é modificado para a largura em caracteres do número antes armazenado
    if maior > menor:  # Se maior for mais largo que menor
        return maior  # maior é retornado
    else:  # Caso contrário
        return menor  # menor é retornado


def quantosAlgarismos(n):  # Função que analísa a quantidade de caracteres de cada elemento da tabela
    if n < 0:  # Se n for menor do que 0
        algarismos = 2  # algarismos recebe 2
        while n < -9:  # Enquanto n for menor que -9 o laço não será interrompido
            algarismos += 1  # algarismos é incrementado em 1
            n //= 10  # n é divido por 10 (divisão inteira)
        return algarismos  # algarismos é retornado
    else:  # Caso contrário
        algarismos = 1  # algarismos recebe 1
        while n > 9:  # enquanto n for maior que 9
            algarismos += 1  # algarismos é incrementado em 1
            n //= 10  # n é dividido por 10
        return algarismos  # algarismos é retornado


# Abaixo encontra-se a função que exibe a matriz
# para conseguir exibir os valores corretamente alinhados
# precisei descobrir o elemento de maior largura da matriz
# e quantas casas decimais ele possui.
# tendo feito isso depois eu imprimo na tela um espaço
# para cada algarismo de diferença entre o maior algarismo
# e o elemento a ser exibido.


def mostraMatriz(matriz):  # Função que exibe a matriz. Recebe como parametro apenas uma matriz
    tamanhoColuna = larguraColuna(matriz)  # tamanhoColuna recebe a largura máxima da matriz
    for linha in range(len(matriz)):  # Laço que controla a linha a ser exibida
        for coluna in range(len(matriz[linha])):  # laço que controla a coluna a ser exibida
            for espaco in range(tamanhoColuna - quantosAlgarismos(matriz[linha][coluna])):  # Laço que controla os
            # espaços necessário para alinhar a matriz
                print(" ", end="")  # Imprime um espaço na tela de acordo com a diferença entre maior e o elemento a ser
            # exibido. Pode não ser impresso.
            print(" %d" % matriz[linha][coluna], end="")  # Imprime na tela o elemento correspondente a linha e coluna
            # de seus laços correspondentes
        print()  # Imprime uma quebra de linha
    print()  # Imprime outra quebra de linha para não agrupar matrizes similares
    return None  # Nada é retornado


def somaMatriz(matriz1, matriz2):  # Função que fará a soma das matrizes. Recebe como parametro as duas matrizes
    if len(matriz1) == len(matriz2) and len(matriz1[0]) == len(matriz2[0]):  # Verifica se é possível fazer a soma. Se
        # for
        soma = []  # soma recebe uma lista vazia
        for l in range(len(matriz1)):  # Laço que controla a quantidade de linhas da matriz
            soma.append([])  # É acrescentado uma linha a matriz soma
            for c in range(len(matriz1[l])):  # laço que controla a quantidade de colunas da matriz
                soma[l].append(matriz1[l][c] + matriz2[l][c])  # É inserido a coluna na matriz com o valor
                # correspondente a soma do mesmo campo correspondente das duas matrizes recebidas
        return soma  # Matriz soma é retornada
    else:
        return 0


def produtoMatriz(matriz1, matriz2):  # Função que obterá o produto das matrizes. Recebe como parametro apenas as duas
    # matrizes
    if len(matriz1[0]) == len(matriz2):  # Verifica se é possível multiplicar as matrizes. A quantidade de colunas da
        # primenira deve ser igual a quantidade de linhas da segunda
        produto = []  # Variável produto recebe uma lista vazia
        for l in range(len(matriz1)):  # Laço que controlará a quantidade de linhas da matriz
            produto.append([])  # Insere uma linha na matriz produto
            for c in range(len(matriz2[0])):  # Laço que controlará a quantidade de matriz
                aux = 0  # Variável aux é criada para armazenar o valor do somaatório das multiplicações de cada linha
                for v in range(len(matriz2)):  # Laço que controlará a quantidade de multiplicações de cada posição da
                    # matriz
                    aux += matriz1[l][v] * matriz2[v][c]  # aux é oncrementada da multiplicação de cada posição
                    # correspondente
                produto[l].append(aux)  # É criada uma coluna na matriz onde é armazenado o valor de aux
        return produto  # Retorna a matriz produto
    else:  # Caso não seja possível multiplicar as matrizes
        return 0  # é retornado o valor 0

# Programa Principal

valorMinimo = int(input("Informe o valor inteiro mínimo da faixa: "))           # valorMinimo recebe o menor valor da
#  faixa
valorMaximo = int(input("Informe o valor inteiro máximo da faixa: "))           # valorMaximo recebe o maior valor da
#  faixa
linhas1 = int(input("Informe a quantidade de linhas da primeira matriz: "))     # linhas1 recebe a quantidade de linhas
# da primeira matriz
colunas1 = int(input("Informe a quantidade de colunas da primeira matriz: "))   # colunas1 recebe a quantidade de
# colunas da primeira matriz
linhas2 = int(input("Informe a quantidade de linhas da segunda matriz: "))      # linhas2 recebe a quantidade de linhas
# da segunda matriz
colunas2 = int(input("Informe a quantidade de colunas da segunda matriz: "))    # colunas2 recebe a quantidade de
# colunas da segunda matriz
matriz1 = constroiMatriz(linhas1, colunas1, valorMinimo, valorMaximo)           # matriz1 é formada com a função
# constroiMatriz
matriz2 = constroiMatriz(linhas2, colunas2, valorMinimo, valorMaximo)           # matriz2 é formada com a função
# constroiMatriz
mostraMatriz(matriz1)       # Exibe a matriz1 conforme específicado na questão
mostraMatriz(matriz2)       # Exibe a matriz2 conforme específicado na questão
soma = somaMatriz(matriz1, matriz2)     # soma recebe a soma da matriz1 e matriz2
if soma != 0:                                                           # Se soma não receber apenas 0 como retorno de
    # somaMatriz
    mostraMatriz(soma)                                                  # a matriz soma é exibida na tela.
else:                                                                   # Caso contrário
    print("Não é possível somar matrizes de dimensões diferentes.")     # é exibida a mensagem pedida na questão
produto = produtoMatriz(matriz1, matriz2)                               # produto recebe o produto da matriz 1 e matriz2
if produto != 0:                                                        # Se produto for diferente de 0
    mostraMatriz(produto)                                               # a matriz produto é exibida.
else:                                                                                                                                       # Caso contrário
    print("Não é possível multiplicar matrizes se a quantidade de colunas da primeira é diferente da ", end="")
    print("quantidade de linhas da segunda.")     # é exibida a mensagem pedida na questão.