import random  # Importa a biblioteca ramdom para que possam ser gerados valores aleatórios a serem inseridos no vetor.

# Subprogramas


def preencheVetor(min, max, n):  # Função responsável por criar o vetor
    vetor = []  # Cria um vetor vazio
    for i in range(n):  # Laço definido que rodará n vezes.
        vetor.append(random.uniform(min, max))  # Insere um número de ponto flutuante no vetor.
    return vetor  # Retorna o vetor formado


def trocar(vals, posX, posY):  # Função que trocará as posições recebidas
    temp = vals[posX]  # Variável temp recebe o valor da posX de lista
    vals[posX] = vals[posY]  # posX da lista recebe posY da lista
    vals[posY] = temp  # posY da lista recebe o valor da variável temp
    return None  # Nada é retornado



def selecionarMenor(vals, inicio, r):  # Função que retornará a posição do menor valor
    localMenor = inicio  # Variável localMEnor recebe a posição iniciala a ser buscada
    for pos in range(inicio, inicio + r):  # Laço que varrerá a lista a procura da do menor valor
        if vals[pos] < vals[localMenor]:  # Verifica se a posição verificada é menor que a posição menor
            localMenor = pos  # se for localMenor recebe a nova posição
    return localMenor  # Retorna localMenor


def ordena(valores, indice, q):  # Função que ordenará a lista, vetor... Recebe como parametros a lista, o indice onde
    #  se encontra o valor da posição a começar a ordenação, e a quantidade de itens a ser ordenado. Essa função é
    # praticamente uma cópia da função da aula 7, porém adaptada para realizar as trocas a partir de indice até o valor
    # da janela.
    for ind in range(indice, indice + q):  # Laço que ordenará os valores começando na posição indice e indo até
        # indice + q
        menor = selecionarMenor(valores, ind, q)  # menor recebe o valor retornado da função seleciona Menor
        trocar(valores, ind, menor)  # Função trocar muda as posições dos elementos do vetor
        q -= 1  # Aqui foi uma solução que eu encontrei para corrigir um problema que me custou uma noite de sono.
        # As trocas estava sendo feitas sempre até um valor a mais a cada laço. Resolvi o problema simplesmente
        # decrementando q
    return None  # Nada é retornado


def verificaSetor(lista, x):  #Função que ordenará a janela com a maior soma entre os elementos da matriz.
    # Recebe como parametros o vetor a ser ordenado e o tamanho da janela
    tamanho = len(lista) - x  # Varável tamanho recebe o valor a ser verificado na lista. Corresponde a quantidade de
    # itens do vetor menos o tamanho da janela
    soma = lista[0]  # Variável soma recebe o primeiro elemento da matriz. Não pode ter um valor fixo, pois se
    # tratando de número aleatório pode-se esperar qualeuer coisa! XD
    maior = 0  # Variável maior recebe 0
    for item in range(tamanho):  # Laço que varrerá os primeiros elementos da lista
        aux = 0  # Variável aux recebe 0
        for s in range(x):  # Laço que varrerá a janela efetuando a soma dos elementos da lista dentro a partir do
            # item verificado no laço anterior até o tamanho da janela
            aux += lista[item + s]  # aux é incrementado com o valor da posição correspondete entre item e s
        if aux > soma:  # Se aux for maior que soma
            soma = aux  # soma receberá aux
            maior = item  # maior receberá item
    ordena(lista, maior, x)  # Função que ordenará a lista. São passados como parametros, lista, maior e x (tamanho da
    # janela)
    return None  #

# Programa Principal

valorMinimo = int(input("Informe o valor mínimo da faixa: "))  # Recebe o valor minimo que será sorteado
valorMaximo = int(input("Informe o valor máximo da faixa: "))  # Recebe o valor máximo que será sorteado
n = int(input("Informe a quantidade de valores a serem sorteados: "))  # Recebe a quantidade de itens que conterão o
# vetor
m = int(input("Informe o tamanho da janela: "))  # Recebe o tamanho da janela que será verificada a maior soma
# de elementos e depois ordenada
vetor = preencheVetor(valorMinimo, valorMaximo, n)  # Variável vetor recebe o valor retornado pela função que cria o
# vetor. São passados como parâmetro o valor mínimo, valor máximo e a quantidade de itens.
print(vetor)  # O vetor é impresso
verificaSetor(vetor, m)  # Função que ordenará a janela com a maior soma do vetor
print(vetor)  # O vetor é impresso com a janela da maior soma ordenado