# AD1 - Questão 2

# Subprogramas

def palindromo(texto):
    if len(texto) <= 1:
        return True
    else:
        return texto[0] == texto[len(texto) - 1] and palindromo(texto[1:len(texto) - 1])


# Programa Principal
linha = input()
while linha != "fim":
    linha = linha.replace(" ", "").upper()
    if palindromo(linha):
        print("é palíndomo")
    else:
        print("não é palíndromo")
    linha = input()
