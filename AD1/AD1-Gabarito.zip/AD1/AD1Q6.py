# AD1 - Questão 6

# Subprogramas

def construir(tamanho, menor, maior):
    from random import uniform
    vals = [0.0] * tamanho
    for i in range(tamanho):
        vals[i] = uniform(menor, maior)
    return vals


def somar(valores, pos, janela):
    total = 0
    for i in range(pos, pos + janela):
        total += valores[pos]
    return total


def ordenarSetorPorSelecao(valores, inicio, fim):
    for i in range(inicio, fim):
        posMenor = i
        valorMenor = valores[i]
        for j in range(i + 1, fim):
            if valores[j] < valorMenor:
                posMenor = j
                valorMenor = valores[j]
        temp = valores[i]
        valores[i] = valores[posMenor]
        valores[posMenor] = temp
    return None


def identificarOrdenarSetor(valores, janela):
    posVencedor = 0
    somaVencedor = somar(valores, 0, janela)
    for posAtual in range(1, len(valores) + 1 - janela):
        somaAtual = somar(valores, posAtual, janela)
        if somaAtual > somaVencedor:
            posVencedor = posAtual
            somaVencedor = somaAtual
    ordenarSetorPorSelecao(valores, posVencedor, posVencedor + janela)
    return None


# Programa Principal
l = float(input("Informe o valor mínimo da faixa: "))
h = float(input("Informe o valor máximo da faixa: "))
n = int(input("Informe a quantidade de valores a serem sorteados: "))
m = int(input("Informe o tamanho da janela: "))
valores = construir(n, l, h)
print(valores)
identificarOrdenarSetor(valores, m)
print(valores)
