# AD1 - Questão 5

# Subprogramas

def construir(numLinhas, numColunas, menor, maior):
    from random import randint
    valores = []
    for linha in range(numLinhas):
        novaLinha = []
        for coluna in range(numColunas):
            novaLinha.append(randint(menor, maior))
        valores.append(novaLinha)
    return valores


def mostrar(valores):
    maxQtd = 0
    for linha in valores:
        for valor in linha:
            qtd = len(str(valor))
            if qtd > maxQtd:
                maxQtd = qtd
    formato = "%" + str(maxQtd) + "d"
    for linha in valores:
        for valor in linha:
            print(formato % (valor), end=" ")
        print()
    return None


def somar(valoresA, valoresB):
    linhas = len(valoresA)
    colunas = len(valoresA[0])
    if linhas != len(valoresB) or colunas != len(valoresB[0]):
        return None
    else:
        resp = []
        for linha in range(linhas):
            novaLinha = []
            for coluna in range(colunas):
                novaLinha.append(valoresA[linha][coluna] + valoresB[linha][coluna])
            resp.append(novaLinha)
        return resp


def multiplicar(valoresA, valoresB):
    dimIguais = len(valoresB)
    if len(valoresA[0]) != dimIguais:
        return None
    else:
        linhas = len(valoresA)
        colunas = len(valoresB[0])
        resp = []
        for linha in range(linhas):
            novaLinha = []
            for coluna in range(colunas):
                novaLinha.append(0)
                for k in range(dimIguais):
                    novaLinha[coluna] += valoresA[linha][k] * valoresB[k][coluna]
            resp.append(novaLinha)
        return resp


# Programa Principal
l = int(input("Informe o valor inteiro mínimo da faixa: "))
h = int(input("Informe o valor inteiro máximo da faixa: "))

qtdLinsPrimeira = int(input("Informe a quantidade de linhas da primeira matriz: "))
qtdColsPrimeira = int(input("Informe a quantidade de colunas da primeira matriz: "))
valoresPrimeira = construir(qtdLinsPrimeira, qtdColsPrimeira, l, h)

qtdLinsSegunda = int(input("Informe a quantidade de linhas da segunda matriz: "))
qtdColsSegunda = int(input("Informe a quantidade de colunas da segunda matriz: "))
valoresSegunda = construir(qtdLinsSegunda, qtdColsSegunda, l, h)

mostrar(valoresPrimeira)
mostrar(valoresSegunda)

valoresSoma = somar(valoresPrimeira, valoresSegunda)
if valoresSoma == None:
    print("Não é possível somar matrizes de dimensões diferentes")
else:
    mostrar(valoresSoma)

valoresProduto = multiplicar(valoresPrimeira, valoresSegunda)
if valoresProduto == None:
    print("Não é possível multiplicar matrizes se quantidade de colunas da primeira é diferente da quantidade de linhas da segunda")
else:
    mostrar(valoresProduto)
