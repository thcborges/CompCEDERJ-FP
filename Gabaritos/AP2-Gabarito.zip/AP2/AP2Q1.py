# AP2 - Questão 1

# Subprogramas

def produzConjunto(nArq, conjPals):
    bd = open(nArq, "r")
    for linha in bd:
        palavras = linha.split()
        for pal in palavras:
            conjPals.add(pal)
    bd.close()
    return None


def mostra(conj):
    for x in conj:
        print(x)
    print()
    return None


# Programa Principal
nomeArq = input("Diga o nome do arquivo: ")
conjuntoPalavras = set()
produzConjunto(nomeArq, conjuntoPalavras)
mostra(conjuntoPalavras)
