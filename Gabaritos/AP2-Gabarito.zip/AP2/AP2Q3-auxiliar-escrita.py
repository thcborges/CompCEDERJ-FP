# AP2 - Questão 3 - Programa auxiliar (a escrita e entrega deste programa não faz parte da avaliação)

import struct
Registro = struct.Struct("f f f")

registros = [(3.5, 6.7, 3.4), (3.5, 5.2, 1.0), (1.0, 5.6, 3.4), (9.0, 8.5, 1.2)];

try:
    with open("bagunca.bin", "wb") as arq:
        arq.write(struct.pack("i", len(registros)))
        for campos in registros:
            arq.write(Registro.pack(campos[0], campos[1], campos[2]))
except IOError:
    print("Erro ar abrir ou manipular o arquivo.")
