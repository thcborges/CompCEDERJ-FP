# AP2 - Questão 3 - Programa auxiliar (a escrita e entrega deste programa não faz parte da avaliação)

import struct
Registro = struct.Struct("f f f")

try:
    with open("bagunca.bin", "rb") as arq:
        n = struct.unpack("i", arq.read(4))[0]
        print(n)
        for ind in range(n):
            print(Registro.unpack(arq.read(Registro.size)))
except IOError:
    print("Erro ar abrir ou manipular o arquivo.")
