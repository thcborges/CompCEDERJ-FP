# AP2 - Questão 2

# Subprogramas

def produzDicionario(nArq, dicPals):
    bd = open(nArq, "r")
    for linha in bd:
        palavras = linha.split()
        for pal in palavras:
            if dicPals.get(pal) == None:
                dicPals[pal] = 1
            else:
                dicPals[pal] += 1
    bd.close()
    return None


def mostraOrdenado(dicPals):
    for chave, valor in sorted(dicPals.items()):
        print(chave, "ocorreu", valor, "vez(es)")
    print()
    return None


# Programa Principal
nomeArq = input("Diga o nome do arquivo: ")
dicionarioPalavras = dict()
produzDicionario(nomeArq, dicionarioPalavras)
mostraOrdenado(dicionarioPalavras)
