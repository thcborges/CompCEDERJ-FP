# AP2 - Questão 3

import struct
Registro = struct.Struct("f f f")


# Subprogramas

def ler(arq, ind):
    arq.seek(4 + ind * Registro.size, 0)
    return Registro.unpack(arq.read(Registro.size))


def escrever(arq, ind, campos):
    arq.seek(4 + ind * Registro.size, 0)
    arq.write(Registro.pack(campos[0], campos[1], campos[2]))


def ordenar(arq, n):
    for j in range(n):
        iMin = j
        camposMin = ler(arq, iMin)
        for i in range(j+1, n):
            camposAtual = ler(arq, i)
            if camposAtual < camposMin:
                iMin = i
                camposMin = camposAtual

        if iMin != j:
            camposAtual = ler(arq, j)
            escrever(arq, j, camposMin)
            escrever(arq, iMin, camposAtual)

    return None


# Programa Principal
try:
    with open("bagunca.bin", "r+b") as arqBinario:
        qtdRegistros = struct.unpack("i",arqBinario.read(4))[0]
        ordenar(arqBinario, qtdRegistros)
except IOError:
    print("Erro ar abrir ou manipular o arquivo.")
