# AP3 - Questão 3 (a)

# Subprogramas

def analisaPadrao(x):
    return (len(x) == 0) or (x[len(x) - 1] == (2 * x[0] % 10) and analisaPadrao(x[1:len(x)-1]))


# Programa Principal
txt = input("Informe valores inteiros, separados por espaço em branco: ")
nums = [int(n) for n in txt.split()]
if analisaPadrao(nums):
    print("Padrão válido")
else:
    print("Padrão inválido")
