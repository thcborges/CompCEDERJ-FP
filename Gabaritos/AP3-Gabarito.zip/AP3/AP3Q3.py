# AP3 - Questão 3

# Subprogramas

def centroideDosPontos(nArq):
    n = 0
    c = (0.0, 0.0)
    pontos = open(nArq, "r")
    for linha in pontos:
        x, y = linha.split()
        c = (c[0]+float(x), c[1]+float(y))
        n = n + 1
    c = (c[0]/n, c[1]/n)
    print("Centroide: x = %1.2f, y = %1.2f\n" % c)
    pontos.close()
    return c


def pontosNaCircunferencia(nArq, c, r):
    from math import sqrt
    print("Pontos na circunferência de raio %1.2f" % r)
    pontos = open(nArq, "r")
    for linha in pontos:
        x, y = linha.split()
        p = (float(x), float(y))
        if sqrt((p[0]-c[0])**2 + (p[1]-c[1])**2) <= r:
            print("x = %1.2f, y = %1.2f" % p)
    print()
    pontos.close()
    return None


# Programa Principal
nomeArq = input()
centroide = centroideDosPontos(nomeArq)

raio = float(input())
while raio > 0.0:
    pontosNaCircunferencia(nomeArq, centroide, raio)
    raio = float(input())
