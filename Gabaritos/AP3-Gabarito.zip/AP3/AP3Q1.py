# AP3 - Questão 3 (a)

# Subprogramas

def construir(qLins, qCols, min, max):
    from random import randint
    vs = []
    for lin in range(qLins):
        novaLinha = []
        for col in range(qCols):
            novaLinha.append(randint(min, max))
        vs.append(novaLinha)
    return vs


def mostrar(vals):
    print("---------   Matriz   ---------")
    for linha in vals:
        for x in linha:
            print("%4d" % x, end=" ")
        print()
    print("------------------------------")
    return None


def linhaMaiorSoma(vals):
    def somaLinha(pL, vs):
        total = 0
        for valor in vs[pL]:
            total += valor
        return total

    posLinMaior = 0
    somaMaior = somaLinha(0, vals)
    for lin in range(1, len(vals)):
        somaAtual = somaLinha(lin, vals)
        if somaAtual > somaMaior:
            posLinMaior = lin
            somaMaior = somaAtual
    print("Linha de Maior Soma: ", posLinMaior, "com soma:", somaMaior)
    print("Conteúdo:")
    for x in vals[posLinMaior]:
        print(x, end=" ")
    print()
    return None


def colunaMaiorSoma(vals):
    def somaColuna(pC, vs):
        total = 0
        for linha in range(len(vs)):
            total += vs[linha][pC]
        return total

    posColMaior = 0
    somaMaior = somaColuna(0, vals)
    for col in range(1, len(vals[0])):
        somaAtual = somaColuna(col, vals)
        if somaAtual > somaMaior:
            posColMaior = col
            somaMaior = somaAtual
    print("Coluna de Maior Soma:", posColMaior, "com soma:", somaMaior)
    print("Conteúdo:")
    for lin in range(len(vals)):
        print("   ", vals[lin][posColMaior])
    print()
    return None


# Programa Principal
dimensoes = input("Diga a quantidade de linhas e colunas da matriz bidimensional: ").split()
faixa = input("Diga a faixa de variação de valores: mínima e máxima: ").split()
qtdLinhas = int(dimensoes[0])
qtdColunas = int(dimensoes[1])
minimo = int(faixa[0])
maximo = int(faixa[1])
valores = construir(qtdLinhas, qtdColunas, minimo, maximo)
mostrar(valores)
linhaMaiorSoma(valores)
colunaMaiorSoma(valores)
