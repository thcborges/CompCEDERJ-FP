# AP3 - Questão 3 (b)

# Subprogramas

def mdc(a, b):
    if b > 0:
        return mdc(b, a % b);
    else:
        return a


# Programa Principal
valA = int(input("Informe o primeiro valor inteiro: "))
valB = int(input("Informe o segundo valor inteiro: "))
print("O máximo divisor comum de %d e %d é %d." % (valA, valB, mdc(valA, valB)))
