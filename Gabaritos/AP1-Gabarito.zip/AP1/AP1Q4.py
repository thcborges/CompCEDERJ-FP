# AP1 - Questão 4

# Subprogramas
def obterDimensoes():
    linhas = int(input("Informe a quantidade de linhas da matriz: "))
    colunas = int(input("Informe a quantidade de colunas da matriz: "))
    return linhas, colunas


def construirMatriz(linhas, colunas):
    from random import randint
    matriz = []
    for linha in range(linhas):
        novaLinha = []
        for coluna in range(colunas):
            novaLinha.append(randint(-10, +10))
        matriz.append(novaLinha)
    return matriz


def exibirSubmatriz(matriz, linhaInicial, linhaFinal, colunaInicial, colunaFinal):
    for linha in range(linhaInicial, linhaFinal + 1):
        for coluna in range(colunaInicial, colunaFinal + 1):
            print(matriz[linha][coluna], end=" ")
        print()
    print()
    return None


# Programa Principal
lins, cols = obterDimensoes()

m = construirMatriz(lins, cols)
exibirSubmatriz(m, 0, lins - 1, 0, cols - 1)

if lins < 3 or cols < 3:
    print("A matriz é muito pequena.")
else:
    for lin in range(lins - 2):
        for col in range(cols - 2):
            exibirSubmatriz(m, lin, lin + 2, col, col + 2)
