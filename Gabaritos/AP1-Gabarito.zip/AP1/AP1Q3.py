# AP1 - Questão 3

# Subprogramas
def construir():
    matriz = []
    for linha in range(5):
        novaLinha = []
        for coluna in range(5):
            novaLinha.append(input("Informe a palavra para a posição (lin = %d, col = %d): " % (linha, coluna)))
        matriz.append(novaLinha)
    return matriz


def mostrar(matriz):
    for linha in range(len(matriz)):
        for coluna in range(len(matriz[linha])):
            print(matriz[linha][coluna], end=" ")
        print()
    return None


def buscar(matriz, palavra):
    for linha in range(len(matriz)):
        for coluna in range(len(matriz[linha])):
            if matriz[linha][coluna] == palavra:
                print("Palavra encontrada em (lin = %d, col = %d)." % (linha, coluna))
                return None
    print("Palavra não encontrada.")
    return None


# Programa Principal
m = construir()
mostrar(m)

s = input("Informe uma palavra para a busca: ")
while s != "Fim":
    buscar(m, s)
    s = input("Informe uma palavra para a busca: ")
