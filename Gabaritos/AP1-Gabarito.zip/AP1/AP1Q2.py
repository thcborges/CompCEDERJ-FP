# AP1 - Questão 2

# Subprogramas

def converte(numDecimal, base):
    if numDecimal < base:
        return str(numDecimal)
    else:
        return converte(numDecimal // base, base) + str(numDecimal % base)


# Programa Principal
numLido = int(input())
while numLido != -1:
    for base in range(2, 10):
        print(converte(numLido, base), end=" ")
    print()
    numLido = int(input())
