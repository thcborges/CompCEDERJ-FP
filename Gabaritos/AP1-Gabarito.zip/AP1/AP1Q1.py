# AP1 - Questão 1

# Subprogramas

def gerar():
    from random import random
    tamanho = int(input())
    resposta = [0.0] * tamanho
    for i in range(tamanho):
        resposta[i] = random()
    return resposta


def ordenar(vals):
    for posInicial in range(len(vals) - 1):
        posMenor = posInicial
        for posAtual in range(posInicial + 1, len(vals)):
            if vals[posAtual] < vals[posMenor]:
                posMenor = posAtual
        temp = vals[posInicial]
        vals[posInicial] = vals[posMenor]
        vals[posMenor] = temp
    return None


# Programa Principal
valores = gerar()
print(valores)

ordenar(valores)
print(valores)
