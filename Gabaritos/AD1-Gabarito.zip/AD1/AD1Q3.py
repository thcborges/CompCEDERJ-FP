# AD1 - Questão 3

# Subprogramas

def atualizar(pares, tipo, peso):
    if peso > 100:
        peso = 0
    pos = 0
    while pares[pos] != None and pares[pos][0] != tipo:
        pos += 1
    if pares[pos] == None or peso > pares[pos][1]:
        pares[pos] = (tipo, peso)
    return None


def mostrar(pares):
    total = 0
    for tipo, peso in pares:
        total += peso
    print(str(total) + " grama(s)")
    return None


# Programa Principal
t = int(input())
for teste in range(t):
    n, m = input().split(" ")
    maiores = [None] * int(m)
    for i in range(int(n)):
        s, p = input().split(" ")
        p = int(p)
        atualizar(maiores, s, p)
    mostrar(maiores)
