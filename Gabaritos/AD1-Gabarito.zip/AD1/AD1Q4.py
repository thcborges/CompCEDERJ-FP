# AD1 - Questão 4

# Subprogramas

def construir(menor, maior, tamanho):
    from random import randint
    vals = [0] * tamanho
    for i in range(tamanho):
        vals[i] = randint(menor, maior)
    return vals


def unico(pos, valores):
    for i in range(0, pos):
        if valores[pos] == valores[i]:
            return False
    for i in range(pos + 1, len(valores)):
        if valores[pos] == valores[i]:
            return False
    return True


def extremosUnicos(valores):
    resp = (None, None)
    for i in range(len(valores)):
        if unico(i, valores):
            if resp[0] == None:
                resp = (valores[i], valores[i])
            elif valores[i] < resp[0]:
                resp = (valores[i], resp[1])
            elif valores[i] > resp[1]:
                resp = (resp[0], valores[i])
    return resp


# Programa Principal
l = int(input("Informe o valor inteiro mínimo da faixa: "))
h = int(input("Informe o valor inteiro máximo da faixa: "))
n = int(input("Informe a quantidade de valores a serem sorteados: "))
numeros = construir(l, h, n)
print(numeros)
print(extremosUnicos(numeros))
