import struct  # Importando a biblioteca struct


# Subprogramas
# Função que busca em uma arquivo binário um número. Tanto o arquivo (já aberto)
# quanto o número a ser pesquisado são passados como referência
# Primeiramente coloca-se o arquivo em sua posição inicial.
# Em seguida entra-se num laço onde será feita a busca pelo arquivo, volta-se sempre
# uma linha no começo do laço pois está é lida para saber se foi obttido o fim do arquivo.
# Então verifica-se se o numero verificado corresponde ao procurado. Se for é retornado
# sua posição no arquivo dividido pelo tamanho que um inteiro ocupa na memória.
# Caso não seja achado esse número é retornado -1
def buscar(arq, num):
    arq.seek(0)
    while arq.read(1) != b"":
        arq.seek(-1, 1)
        buscado = struct.unpack("i", arq.read(4))[0]
        if buscado == num:
            return int(arq.tell())//4
    return -1


# Programa Principal
# Pede-se para o usuário entrar com o nome do arquivo binário, abre-se ese arquivo
# e em seguida entra-se num laço onde o usuário vai digitar um número para ser buscado
# nesse arquivo e em seguida será exibido na saída padrão sua posição se esse foi
# encontrado ou um a mensagem informando que o arquivo não foi achado. Fecha-se o
# laço e termina-se o programa digitand -1.
nome_arquivo = input("Informe o nome do arquivo binário de números: ")
with open(nome_arquivo, "rb") as arquivo:
    n = int(input("Favor informar o valor a ser encontrado (-1 para sair): "))
    while n != -1:
        posicao = buscar(arquivo, n)
        if posicao == -1:
            print("O número não foi encontrado.\n")
        else:
            print("O número está na posição %d\n" % posicao)
        n = int(input("Favor informar o valor a ser encontrado (-1 para sair): "))
