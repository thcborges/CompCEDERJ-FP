import random  # Importa a biblioteca ramdom para que possam ser gerados valores aleatórios a serem inseridos no vetor.

# Subprogramas


def preencheVetor(min, max, n):   # Função responsável por criar o vetor
    vetor = []  # Cria um vetor vazio
    for i in range(n):  # Laço definido que rodará n vezes.
        vetor.append(random.randint(min, max))  # Insere um número inteiro no vetor.
    return vetor  # Retorna o vetor formado


def verificaMinMax(vetor):  # Função que verifica os valores máximos e minímos únicos do vetor
    menor = None  # Variável menor recebe None, que será repassado caso não haja valores únicos no vetor
    maior = None  # Variável maior recebe None, que será repassado caso não haja valores únicos no vetor
    n = len(vetor)  # Variável n recebe o valor da quanidade de itens do vetor
    v = vetor[:]  # Variável v recebe o vetor passado
    v.sort()  # Ordena o novo vetor

    for item in range(n):  # Laço que varrerá o vetor do menor item para o maior
        if v.count(v[item]) == 1:  # Assim que encontrar um item que seja único
            menor = v[item]  # a variável menor recebe esse item
            break  # e o laço termina

    for item in range(n-1, -1, -1):  # Laço que varrerá o vetor do maior item para o menor
        if v.count(v[item]) == 1:  # Assim que encontrar um item que seja único
            maior = v[item]  # a variável maior recebe esse item
            break  # e o laço termina
    return menor, maior  # Retorna em forma de tupla as variáveis menor e maior.

# Programa Principal

valorMinimo = int(input("Informe o valor inteiro mínimo da faixa: "))  # Recebe o valor minimo que será sorteado
valorMaximo = int(input("Informe o valor inteiro máximo da faixa: "))  # Recebe o valor máximo que será sorteado
n = int(input("Informe a quantidade de valores a serem sorteados: "))  # Recebe a quantidade de itens que contrão o
# vetor
vetor = preencheVetor(valorMinimo, valorMaximo, n)  # Variável vetor recebe o valor retornado pela função que cria o
# vetor. São passados como parâmetro o valor mínimo, valor máximo e a quantidade de itens.
print(vetor)  # O vetor é impresso
extremos = verificaMinMax(vetor)  # A variável extremos recebe o maior e menor valor único retornado como tupla pela
# função verificaMinMax. É passado como paramentro da função a variável vetor.
print(extremos)  # Imprime a variável extrmos na tela.